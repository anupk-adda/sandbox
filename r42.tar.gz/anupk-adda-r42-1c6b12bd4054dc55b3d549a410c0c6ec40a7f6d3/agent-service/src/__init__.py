"""
Running Coach Agent Service
Multi-agent system for running analysis and coaching
"""

__version__ = "1.0.0"

# Made with Bob
