/**
 * Agent Service Client
 * Handles communication with the Python agent service
 */

import { logger } from '../../utils/logger.js';

export interface AgentAnalysis {
  agent: string;
  run_id?: string;
  analysis: string;
  raw_analysis?: string;
  has_splits?: boolean;
  has_hr_zones?: boolean;
  has_weather?: boolean;
  warning?: string;
  error?: string;
  charts?: any[];
  chart_data?: any[];
  weather?: any;
}

export interface AgentPlanResponse {
  summary: {
    goal_distance: string;
    goal_date: string;
    phase: string;
    weekly_focus: string;
    personalized_because?: string;
    next_workouts: Array<{ date: string; name: string; effort?: string }>;
  };
  week: {
    week_start: string;
    week_end: string;
    days: Array<{ date: string; name: string; intensity: string; why?: string; effort?: string }>;
  };
}

export interface AgentServiceConfig {
  baseUrl: string;
  timeout: number;
}

export class AgentClient {
  private baseUrl: string;
  private timeout: number;

  constructor(config?: Partial<AgentServiceConfig>) {
    this.baseUrl = config?.baseUrl || process.env.AGENT_SERVICE_URL || 'http://localhost:5001';
    this.timeout = config?.timeout || 180000; // 180 seconds (3 minutes) - Agent 3 needs ~2 min for 10 runs
  }

  /**
   * Analyze the user's latest run
   */
  async analyzeLastRun(): Promise<AgentAnalysis> {
    logger.info('Calling agent service: analyze latest run');
    
    try {
      const response = await fetch(`${this.baseUrl}/analyze-latest-run`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        signal: AbortSignal.timeout(this.timeout),
      });

      if (!response.ok) {
        const error = await response.json() as any;
        throw new Error(error.detail || `Agent service error: ${response.status}`);
      }

      const data = await response.json() as { status: string; analysis: AgentAnalysis };
      logger.info('Agent service response received', {
        agent: data.analysis?.agent,
        hasError: !!data.analysis?.error
      });

      return data.analysis;
    } catch (error) {
      logger.error('Error calling agent service', { error });
      throw error;
    }
  }

  /**
   * Analyze the user's recent runs (last 3)
   */
  async analyzeRecentRuns(): Promise<AgentAnalysis> {
    logger.info('Calling agent service: analyze recent runs');
    
    try {
      const response = await fetch(`${this.baseUrl}/analyze-recent-runs`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        signal: AbortSignal.timeout(this.timeout),
      });

      if (!response.ok) {
        const error = await response.json() as any;
        throw new Error(error.detail || `Agent service error: ${response.status}`);
      }

      const data = await response.json() as { status: string; analysis: AgentAnalysis };
      logger.info('Agent service response received', {
        agent: data.analysis?.agent,
        hasError: !!data.analysis?.error
      });

      return data.analysis;
    } catch (error) {
      logger.error('Error calling agent service', { error });
      throw error;
    }
  }

  /**
   * Analyze the user's fitness trend (3 months)
   */
  async analyzeFitnessTrend(numRuns = 8): Promise<AgentAnalysis> {
    logger.info('Calling agent service: analyze fitness trend');
    const cappedRuns = Math.min(Math.max(numRuns, 1), 8);
    
    try {
      const response = await fetch(`${this.baseUrl}/analyze-fitness-trends?num_runs=${encodeURIComponent(cappedRuns)}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        signal: AbortSignal.timeout(this.timeout),
      });

      if (!response.ok) {
        const error = await response.json() as any;
        throw new Error(error.detail || `Agent service error: ${response.status}`);
      }

      const data = await response.json() as { status: string; analysis: AgentAnalysis };
      logger.info('Agent service response received', {
        agent: data.analysis?.agent,
        hasError: !!data.analysis?.error
      });

      return data.analysis;
    } catch (error) {
      logger.error('Error calling agent service', { error });
      throw error;
    }
  }

  /**
   * Ask the coach agent a general running question
   */
  async askCoach(question: string): Promise<AgentAnalysis> {
    logger.info('Calling agent service: coach question');
    
    try {
      const response = await fetch(`${this.baseUrl}/coach?question=${encodeURIComponent(question)}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        signal: AbortSignal.timeout(30000), // 30 seconds for general questions
      });

      if (!response.ok) {
        const error = await response.json() as any;
        throw new Error(error.detail || `Agent service error: ${response.status}`);
      }

      const data = await response.json() as { status: string; analysis: AgentAnalysis };
      logger.info('Coach agent response received', {
        agent: data.analysis?.agent,
        hasError: !!data.analysis?.error
      });

      return data.analysis;
    } catch (error) {
      logger.error('Error calling coach agent', { error });
      throw error;
    }
  }

  /**
   * Ask the coach Q&A agent with optional context
   */
  async askCoachWithContext(
    question: string,
    context?: Record<string, any>,
    activityId?: string,
    options?: { force_answer?: boolean }
  ): Promise<AgentAnalysis> {
    logger.info('Calling agent service: coach question with context');

    try {
      const response = await fetch(`${this.baseUrl}/ask-coach`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          question,
          context,
          activity_id: activityId,
          force_answer: options?.force_answer || false,
        }),
        signal: AbortSignal.timeout(30000),
      });

      if (!response.ok) {
        const error = await response.json() as any;
        throw new Error(error.detail || `Agent service error: ${response.status}`);
      }

      const data = await response.json() as any;
      if (data.status && data.status !== 'success') {
        return {
          agent: data.agent || 'CoachQAAgent',
          analysis: data.answer || '',
          error: data.error || 'Coach agent returned an error',
          raw_analysis: data.raw_analysis,
        };
      }

      return {
        agent: data.agent || 'CoachQAAgent',
        analysis: data.answer || data.analysis || '',
        raw_analysis: data.raw_analysis,
      };
    } catch (error) {
      logger.error('Error calling coach Q&A agent', { error });
      throw error;
    }
  }

  /**
   * Get running conditions based on user location
   */
  async getRunningConditions(latitude: number, longitude: number): Promise<AgentAnalysis> {
    logger.info('Calling agent service: running conditions');

    try {
      const response = await fetch(`${this.baseUrl}/running-conditions`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ latitude, longitude }),
        signal: AbortSignal.timeout(15000),
      });

      if (!response.ok) {
        const error = await response.json() as any;
        throw new Error(error.detail || `Agent service error: ${response.status}`);
      }

      const data = await response.json() as { status: string; analysis: AgentAnalysis };
      return data.analysis;
    } catch (error) {
      logger.error('Error calling running conditions agent', { error });
      throw error;
    }
  }

  /**
   * LLM-based intent classification
   */
  async classifyIntent(
    message: string,
    context?: Record<string, any>
  ): Promise<{ type: string; confidence: number; requiresGarminData: boolean; rationale?: string }> {
    logger.info('Calling agent service: classify intent');

    const response = await fetch(`${this.baseUrl}/classify-intent`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ message, context }),
      signal: AbortSignal.timeout(8000),
    });

    if (!response.ok) {
      const error = await response.json() as any;
      throw new Error(error.detail || `Agent service error: ${response.status}`);
    }

    return await response.json() as any;
  }

  /**
   * Generate an adaptive training plan using the agent service
   */
  async generateTrainingPlan(payload: {
    goal_distance: string;
    target_date: string;
    days_per_week: number;
    runner_profile?: Record<string, any>;
    num_runs?: number;
  }): Promise<AgentPlanResponse> {
    logger.info('Calling agent service: generate plan');

    const response = await fetch(`${this.baseUrl}/generate-plan`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(payload),
      signal: AbortSignal.timeout(this.timeout),
    });

    if (!response.ok) {
      const error = await response.json() as any;
      throw new Error(error.detail || `Agent service error: ${response.status}`);
    }

    const data = await response.json() as any;
    if (data.status && data.status !== 'success') {
      throw new Error(data.error || 'Agent service returned an error');
    }

    return data.plan as AgentPlanResponse;
  }

  /**
   * Health check for agent service
   */
  async healthCheck(): Promise<boolean> {
    try {
      const response = await fetch(`${this.baseUrl}/health`, {
        signal: AbortSignal.timeout(5000),
      });
      return response.ok;
    } catch {
      return false;
    }
  }
}

export const agentClient = new AgentClient();

// Made with Bob
